import cv2
import numpy as np
from matplotlib import pyplot as plt


def find_face(input_img):
    face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    face = face_cascade.detectMultiScale(img, 1.1, 4)
    for (x, y, w, h) in face:
        cv2.rectangle(input_img, (x, y), (x + w, y + h), (0, 0, 0), 2)
    cv2.imshow('img', input_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


def fragment_of_the_face(input_image):
    face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    face = face_cascade.detectMultiScale(input_image, 1.1, 4)

    for (x, y, w, h) in face:
        crop_img = img[y:y + int(h * 1.1), x:x + int(w * 1.1)]
    return crop_img



def picture_edges(input_image):
    edges = cv2.Canny(input_image, 50, 100)
    plt.imshow(edges, cmap="gray")
    plt.show()



def delete_small_edges(input_image):
    cv2.Canny(input_image, 50, 100, apertureSize=3)
    edges = cv2.Canny(input_image, 50, 100, apertureSize = 3)
    contours, _ = cv2.findContours(edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    mask = np.zeros(input_image.shape[:2], dtype=input_image.dtype)


    for c in contours:
        if cv2.contourArea(c) > 10:
            cv2.drawContours(mask, [c], 0, (255), -1)


    input_image = cv2.bitwise_and(input_image, input_image, mask=mask)
    cv2.imshow('img', input_image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()



def image_extension(input_image):
    cv2.Canny(input_image, 50, 100, apertureSize=3)
    edges = cv2.Canny(input_image, 50, 100, apertureSize=3)
    kernel = np.ones((5, 5), 'uint8')
    dilate_img = cv2.dilate(edges, kernel, iterations=1)
    return dilate_img


def image_smoothing(input_image):
   image1 = image_extension(input_image)
   cv2.imshow('img1', image1)
   smooth_img1 = cv2.GaussianBlur(image1, (5, 5), cv2.BORDER_DEFAULT)
   cv2.imshow('smooth_img1', smooth_img1)
   smooth_img = cv2.normalize(smooth_img1, None, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32F)
   return smooth_img



def bilateral_filtration(input_image):
   plt.imshow(cv2.bilateralFilter(input_image, 10, 75, 75))
   return input_image



def improved_clarity(input_image):
    kernel = np.array([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]])
    input_image = cv2.filter2D(input_image, -1, kernel)
    return input_image


def final_filtration(input_image):
    M = image_smoothing(input_image)
    F1 = bilateral_filtration(input_image)
    F2 = improved_clarity(input_image)
    final_img = input_image

    height, width = input_image.shape[:2]
    for x in range(width):
        for y in range(height):
            for c in range(3):
                final_img[x, y, c] = M[x,y]*F2[x,y,c]+(1-M[x,y])* F1[x,y,c]
    cv2.imshow('final_img',  final_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


if __name__ == '__main__':
    #img = cv2.imread('lena.jpg')

    img = cv2.imread('lena.jpg', 0)
    img = fragment_of_the_face(img)

    cv2.imshow('orig_img', img)
    img1= image_smoothing(img)
    cv2.imshow('final_img', img1)
    cv2.waitKey(0)
    cv2.destroyAllWindows()